<?php
require __DIR__ . '/_layout.php';
require_admin();
$pend = q1("SELECT COUNT(*) AS c, COALESCE(SUM(amount),0) AS s FROM withdrawals WHERE status IN ('pending','approved')");
$k = [
    ['Total users', (int)qv("SELECT COUNT(*) FROM users"), '#4c9bff'],
    ['Active users (24h)', (int)qv("SELECT COUNT(*) FROM users WHERE last_seen > (NOW() - INTERVAL 1 DAY)"), '#0ecb81'],
    ['Active miners now', (int)qv("SELECT COUNT(*) FROM mining_sessions WHERE status='active' AND ends_at > ?", [time()]), '#f0b90b'],
    ['New users today', (int)qv("SELECT COUNT(*) FROM users WHERE created_at >= CURDATE()"), '#a58bff'],
    ['Total coins mined', fmt(qv("SELECT COALESCE(SUM(total_mined),0) FROM users"), 0), '#f0b90b'],
    ['Coins distributed', fmt(qv("SELECT COALESCE(SUM(total_earned),0) FROM users"), 0), '#2dd4bf'],
    ['USD converted', '$' . fmt(qv("SELECT COALESCE(SUM(usd),0) FROM conversions")), '#0ecb81'],
    ['USD paid out', '$' . fmt(qv("SELECT COALESCE(SUM(amount),0) FROM withdrawals WHERE status='paid'")), '#f6465d'],
    ['Users USD balance (owed)', '$' . fmt(qv("SELECT COALESCE(SUM(usd_balance + usd_pending),0) FROM users")), '#ff8a3d'],
    ['Total referrals', (int)qv("SELECT COUNT(*) FROM referrals"), '#4c9bff'],
    ['Premium users', (int)qv("SELECT COUNT(*) FROM premium_memberships"), '#a58bff'],
    ['Flagged accounts', (int)qv("SELECT COUNT(*) FROM users WHERE flagged=1"), '#f6465d'],
];
admin_head('Dashboard', 'index');
if ((int)$pend['c'] > 0) {
    echo '<div class="alertbox"><span><b>' . (int)$pend['c'] . ' withdrawal(s) waiting</b> · $' . fmt($pend['s']) . '</span><a class="btn gold" style="margin:0" href="withdrawals.php">Review</a></div>';
}
echo '<div class="kpis">';
foreach ($k as $x) {
    echo '<div class="kpi" style="--c:' . $x[2] . '"><span>' . h($x[0]) . '</span><b>' . h((string)$x[1]) . '</b></div>';
}
echo '</div><div class="secttl">Quick menu</div><div class="tiles">';
foreach (admin_menu() as $mk => $mm) {
    if ($mk === 'index') {
        continue;
    }
    echo '<a class="tileg t-' . $mm[3] . '" href="' . $mm[1] . '"><span class="ti">' . aicon($mm[2]) . '</span><b>' . $mm[0] . '</b></a>';
}
echo '</div><div class="secttl">Last 14 days</div><div class="charts">';
echo bar_chart('New users per day', series_days("SELECT DATE(created_at) AS d, COUNT(*) AS v FROM users WHERE created_at >= (CURDATE() - INTERVAL 13 DAY) GROUP BY DATE(created_at)"), false, '#4c9bff');
echo bar_chart('Coins mined per day', series_days("SELECT DATE(created_at) AS d, SUM(amount) AS v FROM mining_transactions WHERE created_at >= (CURDATE() - INTERVAL 13 DAY) GROUP BY DATE(created_at)"), false, '#f0b90b');
echo bar_chart('USD converted per day', series_days("SELECT DATE(created_at) AS d, SUM(usd) AS v FROM conversions WHERE created_at >= (CURDATE() - INTERVAL 13 DAY) GROUP BY DATE(created_at)"), true, '#0ecb81');
echo bar_chart('USD paid out per day', series_days("SELECT DATE(updated_at) AS d, SUM(amount) AS v FROM withdrawals WHERE status='paid' AND updated_at >= (CURDATE() - INTERVAL 13 DAY) GROUP BY DATE(updated_at)"), true, '#f6465d');
echo '</div><p class="muted">Cron URL: <code>' . h(BASE_URL) . '/cron.php?key=' . h(CRON_KEY) . '</code> (run every minute)</p>';
admin_foot();
