<?php
require __DIR__ . '/includes/bootstrap.php';
$secret = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '';
if (!hash_equals(WEBHOOK_SECRET, $secret)) {
    http_response_code(403);
    exit;
}
$upd = json_decode(file_get_contents('php://input'), true);
if (is_array($upd)) {
    try {
        bot_handle($upd);
    } catch (Throwable $e) {
        error_log('webhook: ' . $e->getMessage());
    }
}
echo 'OK';
