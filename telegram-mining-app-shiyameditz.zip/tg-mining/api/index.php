<?php
require __DIR__ . '/../includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function out($arr, $code = 200)
{
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new ApiError('Method not allowed', 405);
    }
    if (!rate_limit('ip:' . client_ip(), 300, 60)) {
        throw new ApiError('Too many requests', 429);
    }
    $in = json_decode(file_get_contents('php://input'), true);
    if (!is_array($in)) {
        $in = [];
    }
    $action = (string)($in['action'] ?? '');
    $auth = validate_init_data($_SERVER['HTTP_X_INIT_DATA'] ?? '');
    $tu = $auth['user'];
    $user = register_user((int)$tu['id'], $tu['username'] ?? null, $tu['first_name'] ?? null, $auth['start_param']);
    if ($user['status'] === 'banned') {
        throw new ApiError('Your account has been banned.', 403);
    }
    if (!rate_limit('u:' . $user['id'], 120, 60)) {
        throw new ApiError('Too many requests. Slow down.', 429);
    }
    q("UPDATE users SET last_seen=NOW() WHERE id=?", [$user['id']]);
    $res = api_dispatch($action, $user, $in);
    out(['ok' => true] + $res);
} catch (ApiError $e) {
    out(['ok' => false, 'error' => $e->getMessage()], $e->status);
} catch (Throwable $e) {
    error_log('api: ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    out(['ok' => false, 'error' => (defined('DEBUG') && DEBUG) ? $e->getMessage() : 'Server error. Please try again.'], 500);
}
